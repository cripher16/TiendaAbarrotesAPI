SELECT
    name AS BaseDatos,
    SUSER_SNAME(owner_sid) AS Propietario
FROM sys.databases
WHERE name = 'TiendaAbarrotes';

USE master;
GO

ALTER AUTHORIZATION
ON DATABASE::TiendaAbarrotes
TO sa;
GO

SELECT * FROM Categoria;
SELECT * FROM Marca;
SELECT * FROM UnidadMedida;
SELECT * FROM Proveedor;
SELECT * FROM EstadoCompra;
SELECT * FROM MetodoPago;
SELECT * FROM Cliente;
SELECT * FROM EstadoVenta;
SELECT * FROM TipoMovimiento;
SELECT * FROM MotivoAjuste;
SELECT TABLE_NAME
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_TYPE = 'BASE TABLE'
ORDER BY TABLE_NAME;
SELECT COUNT(*) AS TotalTablas
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_TYPE = 'BASE TABLE';
USE TiendaAbarrotes;
GO

SELECT IdCategoria, Nombre
FROM Categoria;

SELECT IdMarca, Nombre
FROM Marca;

SELECT IdUnidad, Nombre
FROM UnidadMedida;

SELECT IdProveedor, Nombre FROM Proveedor;
SELECT IdEstadoCompra, Nombre FROM EstadoCompra;
SELECT IdCliente, Nombre FROM Cliente;
SELECT IdEstadoVenta, Nombre FROM EstadoVenta;
SELECT IdMetodoPago, Nombre FROM MetodoPago;
SELECT IdTipoMovimiento, Nombre FROM TipoMovimiento;
SELECT IdMotivoAjuste, Nombre FROM MotivoAjuste;

select * from Producto;
select * from Proveedor;
select * from Venta;