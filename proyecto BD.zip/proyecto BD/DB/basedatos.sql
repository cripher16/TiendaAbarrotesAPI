CREATE DATABASE TiendaAbarrotes;

USE TiendaAbarrotes;

CREATE TABLE Categoria (
    IdCategoria INT IDENTITY(1,1) PRIMARY KEY,
    Nombre VARCHAR(50) NOT NULL UNIQUE,
    Descripcion VARCHAR(150)
);

CREATE TABLE Marca (
    IdMarca INT IDENTITY(1,1) PRIMARY KEY,
    Nombre VARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE UnidadMedida (
    IdUnidad INT IDENTITY(1,1) PRIMARY KEY,
    Nombre VARCHAR(50) NOT NULL UNIQUE,
    Abreviatura VARCHAR(10) NOT NULL
);

CREATE TABLE Proveedor (
    IdProveedor INT IDENTITY(1,1) PRIMARY KEY,
    Nombre VARCHAR(100) NOT NULL,
    Telefono VARCHAR(15),
    Direccion VARCHAR(150)
);

CREATE TABLE Producto (
    IdProducto INT IDENTITY(1,1) PRIMARY KEY,
    Codigo VARCHAR(30) NOT NULL UNIQUE,
    Nombre VARCHAR(100) NOT NULL,
    IdCategoria INT NOT NULL,
    IdMarca INT NOT NULL,
    IdUnidad INT NOT NULL,
    PrecioVenta DECIMAL(10,2) NOT NULL,
    Existencia INT NOT NULL DEFAULT 0,

    CONSTRAINT FK_Producto_Categoria
        FOREIGN KEY (IdCategoria)
        REFERENCES Categoria(IdCategoria),

    CONSTRAINT FK_Producto_Marca
        FOREIGN KEY (IdMarca)
        REFERENCES Marca(IdMarca),

    CONSTRAINT FK_Producto_Unidad
        FOREIGN KEY (IdUnidad)
        REFERENCES UnidadMedida(IdUnidad),

    CONSTRAINT CK_Producto_Precio
        CHECK (PrecioVenta > 0),

    CONSTRAINT CK_Producto_Existencia
        CHECK (Existencia >= 0)
);

CREATE TABLE EstadoCompra (
    IdEstadoCompra INT IDENTITY(1,1) PRIMARY KEY,
    Nombre VARCHAR(30) NOT NULL UNIQUE
);

CREATE TABLE Compra (
    IdCompra INT IDENTITY(1,1) PRIMARY KEY,
    IdProveedor INT NOT NULL,
    IdEstadoCompra INT NOT NULL,
    FechaCompra DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
    Total DECIMAL(10,2) NOT NULL DEFAULT 0,

    CONSTRAINT FK_Compra_Proveedor
        FOREIGN KEY (IdProveedor)
        REFERENCES Proveedor(IdProveedor),

    CONSTRAINT FK_Compra_Estado
        FOREIGN KEY (IdEstadoCompra)
        REFERENCES EstadoCompra(IdEstadoCompra),

    CONSTRAINT CK_Compra_Total
        CHECK (Total >= 0)
);

CREATE TABLE DetalleCompra (
    IdDetalleCompra INT IDENTITY(1,1) PRIMARY KEY,
    IdCompra INT NOT NULL,
    IdProducto INT NOT NULL,
    Cantidad INT NOT NULL,
    PrecioCompra DECIMAL(10,2) NOT NULL,

    CONSTRAINT FK_DetalleCompra_Compra
        FOREIGN KEY (IdCompra)
        REFERENCES Compra(IdCompra),

    CONSTRAINT FK_DetalleCompra_Producto
        FOREIGN KEY (IdProducto)
        REFERENCES Producto(IdProducto),

    CONSTRAINT CK_DetalleCompra_Cantidad
        CHECK (Cantidad > 0),

    CONSTRAINT CK_DetalleCompra_Precio
        CHECK (PrecioCompra > 0)
);

CREATE TABLE MetodoPago (
    IdMetodoPago INT IDENTITY(1,1) PRIMARY KEY,
    Nombre VARCHAR(30) NOT NULL UNIQUE
);

CREATE TABLE PagoCompra (
    IdPagoCompra INT IDENTITY(1,1) PRIMARY KEY,
    IdCompra INT NOT NULL,
    IdMetodoPago INT NOT NULL,
    FechaPago DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
    Monto DECIMAL(10,2) NOT NULL,

    CONSTRAINT FK_PagoCompra_Compra
        FOREIGN KEY (IdCompra)
        REFERENCES Compra(IdCompra),

    CONSTRAINT FK_PagoCompra_Metodo
        FOREIGN KEY (IdMetodoPago)
        REFERENCES MetodoPago(IdMetodoPago),

    CONSTRAINT CK_PagoCompra_Monto
        CHECK (Monto > 0)
);

CREATE TABLE Cliente (
    IdCliente INT IDENTITY(1,1) PRIMARY KEY,
    Nombre VARCHAR(100) NOT NULL,
    Telefono VARCHAR(15)
);

CREATE TABLE EstadoVenta (
    IdEstadoVenta INT IDENTITY(1,1) PRIMARY KEY,
    Nombre VARCHAR(30) NOT NULL UNIQUE
);

CREATE TABLE Venta (
    IdVenta INT IDENTITY(1,1) PRIMARY KEY,
    IdCliente INT NOT NULL,
    IdEstadoVenta INT NOT NULL,
    FechaVenta DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
    Total DECIMAL(10,2) NOT NULL DEFAULT 0,

    CONSTRAINT FK_Venta_Cliente
        FOREIGN KEY (IdCliente)
        REFERENCES Cliente(IdCliente),

    CONSTRAINT FK_Venta_Estado
        FOREIGN KEY (IdEstadoVenta)
        REFERENCES EstadoVenta(IdEstadoVenta),

    CONSTRAINT CK_Venta_Total
        CHECK (Total >= 0)
);

CREATE TABLE DetalleVenta (
    IdDetalleVenta INT IDENTITY(1,1) PRIMARY KEY,
    IdVenta INT NOT NULL,
    IdProducto INT NOT NULL,
    Cantidad INT NOT NULL,
    PrecioUnitario DECIMAL(10,2) NOT NULL,

    CONSTRAINT FK_DetalleVenta_Venta
        FOREIGN KEY (IdVenta)
        REFERENCES Venta(IdVenta),

    CONSTRAINT FK_DetalleVenta_Producto
        FOREIGN KEY (IdProducto)
        REFERENCES Producto(IdProducto),

    CONSTRAINT CK_DetalleVenta_Cantidad
        CHECK (Cantidad > 0),

    CONSTRAINT CK_DetalleVenta_Precio
        CHECK (PrecioUnitario > 0)
);

CREATE TABLE PagoVenta (
    IdPagoVenta INT IDENTITY(1,1) PRIMARY KEY,
    IdVenta INT NOT NULL,
    IdMetodoPago INT NOT NULL,
    FechaPago DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
    Monto DECIMAL(10,2) NOT NULL,

    CONSTRAINT FK_PagoVenta_Venta
        FOREIGN KEY (IdVenta)
        REFERENCES Venta(IdVenta),

    CONSTRAINT FK_PagoVenta_Metodo
        FOREIGN KEY (IdMetodoPago)
        REFERENCES MetodoPago(IdMetodoPago),

    CONSTRAINT CK_PagoVenta_Monto
        CHECK (Monto > 0)
);

CREATE TABLE TipoMovimiento (
    IdTipoMovimiento INT IDENTITY(1,1) PRIMARY KEY,
    Nombre VARCHAR(30) NOT NULL UNIQUE
);

CREATE TABLE MovimientoInventario (
    IdMovimiento INT IDENTITY(1,1) PRIMARY KEY,
    IdProducto INT NOT NULL,
    IdTipoMovimiento INT NOT NULL,
    FechaMovimiento DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
    Cantidad INT NOT NULL,
    Observacion VARCHAR(150),

    CONSTRAINT FK_Movimiento_Producto
        FOREIGN KEY (IdProducto)
        REFERENCES Producto(IdProducto),

    CONSTRAINT FK_Movimiento_Tipo
        FOREIGN KEY (IdTipoMovimiento)
        REFERENCES TipoMovimiento(IdTipoMovimiento),

    CONSTRAINT CK_Movimiento_Cantidad
        CHECK (Cantidad > 0)
);

CREATE TABLE MotivoAjuste (
    IdMotivoAjuste INT IDENTITY(1,1) PRIMARY KEY,
    Nombre VARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE AjusteInventario (
    IdAjuste INT IDENTITY(1,1) PRIMARY KEY,
    IdMotivoAjuste INT NOT NULL,
    FechaAjuste DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
    Observacion VARCHAR(150),

    CONSTRAINT FK_Ajuste_Motivo
        FOREIGN KEY (IdMotivoAjuste)
        REFERENCES MotivoAjuste(IdMotivoAjuste)
);

CREATE TABLE DetalleAjuste (
    IdDetalleAjuste INT IDENTITY(1,1) PRIMARY KEY,
    IdAjuste INT NOT NULL,
    IdProducto INT NOT NULL,
    CantidadAnterior INT NOT NULL,
    CantidadNueva INT NOT NULL,

    CONSTRAINT FK_DetalleAjuste_Ajuste
        FOREIGN KEY (IdAjuste)
        REFERENCES AjusteInventario(IdAjuste),

    CONSTRAINT FK_DetalleAjuste_Producto
        FOREIGN KEY (IdProducto)
        REFERENCES Producto(IdProducto),

    CONSTRAINT CK_DetalleAjuste_Anterior
        CHECK (CantidadAnterior >= 0),

    CONSTRAINT CK_DetalleAjuste_Nueva
        CHECK (CantidadNueva >= 0)
);

INSERT INTO Categoria (Nombre, Descripcion)
VALUES
('Bebidas', 'Gaseosas, jugos y agua'),
('Lacteos', 'Leche, queso y yogurt'),
('Granos', 'Arroz, frijol y maiz'),
('Limpieza', 'Productos para limpieza'),
('Golosinas', 'Dulces y chocolates'),
('Aceites', 'Aceites para cocinar');

INSERT INTO Marca (Nombre)
VALUES
('Coca Cola'),
('Pepsi'),
('Dos Pinos'),
('Diana'),
('Ideal'),
('La Popular'),
('Malher'),
('Del Monte');

INSERT INTO UnidadMedida (Nombre, Abreviatura)
VALUES
('Unidad', 'Und'),
('Libra', 'Lb'),
('Kilogramo', 'Kg'),
('Litro', 'L'),
('Botella', 'Bot'),
('Bolsa', 'Bls');

INSERT INTO Proveedor (Nombre, Telefono, Direccion)
VALUES
('Distribuidora Central', '55551111', 'Guatemala'),
('Bebidas Nacionales', '55552222', 'Escuintla'),
('Productos del Sur', '55553333', 'Mazatenango'),
('Distribuidora La Economica', '55554444', 'Retalhuleu'),
('Comercial San Jose', '55555555', 'Quetzaltenango');

INSERT INTO EstadoCompra (Nombre)
VALUES
('Pendiente'),
('Completada'),
('Cancelada');

INSERT INTO MetodoPago (Nombre)
VALUES
('Efectivo'),
('Transferencia');

INSERT INTO Cliente (Nombre, Telefono)
VALUES
('Consumidor Final', NULL),
('Juan Perez', '45671234'),
('Maria Lopez', '56782345'),
('Carlos Ramirez', '67893456'),
('Ana Morales', '78904567');

INSERT INTO EstadoVenta (Nombre)
VALUES
('Pendiente'),
('Completada'),
('Cancelada');

INSERT INTO TipoMovimiento (Nombre)
VALUES
('Entrada'),
('Salida'),
('Ajuste');

INSERT INTO MotivoAjuste (Nombre)
VALUES
('Producto vencido'),
('Producto dañado'),
('Error de conteo'),
('Producto extraviado');

INSERT INTO Producto
(Codigo, Nombre, IdCategoria, IdMarca, IdUnidad, PrecioVenta, Existencia)
VALUES
('P001', 'Coca Cola 600ml',
 (SELECT IdCategoria FROM Categoria WHERE Nombre = 'Bebidas'),
 (SELECT IdMarca FROM Marca WHERE Nombre = 'Coca Cola'),
 (SELECT IdUnidad FROM UnidadMedida WHERE Nombre = 'Botella'),
 8.00, 30),

('P002', 'Pepsi 600ml',
 (SELECT IdCategoria FROM Categoria WHERE Nombre = 'Bebidas'),
 (SELECT IdMarca FROM Marca WHERE Nombre = 'Pepsi'),
 (SELECT IdUnidad FROM UnidadMedida WHERE Nombre = 'Botella'),
 7.00, 25),

('P003', 'Leche Entera',
 (SELECT IdCategoria FROM Categoria WHERE Nombre = 'Lacteos'),
 (SELECT IdMarca FROM Marca WHERE Nombre = 'Dos Pinos'),
 (SELECT IdUnidad FROM UnidadMedida WHERE Nombre = 'Litro'),
 12.00, 20),

('P004', 'Arroz Blanco',
 (SELECT IdCategoria FROM Categoria WHERE Nombre = 'Granos'),
 (SELECT IdMarca FROM Marca WHERE Nombre = 'Ideal'),
 (SELECT IdUnidad FROM UnidadMedida WHERE Nombre = 'Libra'),
 6.00, 50),

('P005', 'Frijol Negro',
 (SELECT IdCategoria FROM Categoria WHERE Nombre = 'Granos'),
 (SELECT IdMarca FROM Marca WHERE Nombre = 'Ideal'),
 (SELECT IdUnidad FROM UnidadMedida WHERE Nombre = 'Libra'),
 8.00, 40),

('P006', 'Galletas Diana',
 (SELECT IdCategoria FROM Categoria WHERE Nombre = 'Golosinas'),
 (SELECT IdMarca FROM Marca WHERE Nombre = 'Diana'),
 (SELECT IdUnidad FROM UnidadMedida WHERE Nombre = 'Unidad'),
 3.00, 60),

('P007', 'Aceite Vegetal',
 (SELECT IdCategoria FROM Categoria WHERE Nombre = 'Aceites'),
 (SELECT IdMarca FROM Marca WHERE Nombre = 'Ideal'),
 (SELECT IdUnidad FROM UnidadMedida WHERE Nombre = 'Botella'),
 18.00, 15),

('P008', 'Sopa Instantanea',
 (SELECT IdCategoria FROM Categoria WHERE Nombre = 'Granos'),
 (SELECT IdMarca FROM Marca WHERE Nombre = 'Malher'),
 (SELECT IdUnidad FROM UnidadMedida WHERE Nombre = 'Unidad'),
 5.00, 35),

('P009', 'Jugo Del Monte',
 (SELECT IdCategoria FROM Categoria WHERE Nombre = 'Bebidas'),
 (SELECT IdMarca FROM Marca WHERE Nombre = 'Del Monte'),
 (SELECT IdUnidad FROM UnidadMedida WHERE Nombre = 'Unidad'),
 6.00, 25),

('P010', 'Golosinas Diana',
 (SELECT IdCategoria FROM Categoria WHERE Nombre = 'Golosinas'),
 (SELECT IdMarca FROM Marca WHERE Nombre = 'Diana'),
 (SELECT IdUnidad FROM UnidadMedida WHERE Nombre = 'Bolsa'),
 10.00, 20);
 --productos--
 SELECT
    p.IdProducto,
    p.Codigo,
    p.Nombre AS Producto,
    c.Nombre AS Categoria,
    m.Nombre AS Marca,
    p.PrecioVenta,
    p.Existencia
FROM Producto p
INNER JOIN Categoria c
    ON p.IdCategoria = c.IdCategoria
INNER JOIN Marca m
    ON p.IdMarca = m.IdMarca;


SELECT IdProveedor, Nombre FROM Proveedor;
SELECT IdProducto, Nombre, Existencia FROM Producto;

--1 compras--
EXEC RegistrarCompra
    @IdProveedor = 2,
    @IdProducto = 7,
    @Cantidad = 5,
    @PrecioCompra = 2.00;

--comprobar--
SELECT * FROM Compra;
SELECT * FROM DetalleCompra;
SELECT * FROM MovimientoInventario;
SELECT IdProducto, Nombre, Existencia FROM Producto;
SELECT IdCliente, Nombre
FROM Cliente;
SELECT IdProducto, Nombre, Existencia, PrecioVenta FROM Producto;

--2 hacer venta--
EXEC RegistrarVenta
    @IdCliente = 4,
    @IdProducto = 6,
    @Cantidad = 2;

--comprobar venta--
SELECT * FROM Venta;
SELECT * FROM DetalleVenta;
SELECT * FROM MovimientoInventario;
SELECT IdProducto, Nombre, Existencia FROM Producto;
--historial ventas--
SELECT
    c.Nombre AS Cliente,
    COUNT(v.IdVenta) AS CantidadVentas,
    SUM(v.Total) AS TotalGastado
FROM Venta v
INNER JOIN Cliente c
    ON v.IdCliente = c.IdCliente
INNER JOIN EstadoVenta e
    ON v.IdEstadoVenta = e.IdEstadoVenta
WHERE e.Nombre = 'Completada'
GROUP BY c.IdCliente, c.Nombre
ORDER BY TotalGastado DESC;

SELECT
    c.Nombre AS Categoria,
    COUNT(p.IdProducto) AS CantidadProductos,
    SUM(p.Existencia) AS TotalExistencias
FROM Producto p
INNER JOIN Categoria c
    ON p.IdCategoria = c.IdCategoria
GROUP BY c.IdCategoria, c.Nombre
ORDER BY TotalExistencias DESC;
--3ventaCliente--
EXEC ReporteVentasCliente;
--4reporte--
EXEC ReporteInventarioCategoria;




