--compra--
CREATE PROCEDURE RegistrarCompra
    @IdProveedor INT,
    @IdProducto INT,
    @Cantidad INT,
    @PrecioCompra DECIMAL(10,2)
AS
BEGIN
    BEGIN TRY
        -- Validar cantidad y precio
        IF @Cantidad <= 0 OR @PrecioCompra <= 0
            THROW 50001, 'Cantidad o precio invalido', 1;

        -- Validar proveedor
        IF NOT EXISTS (
            SELECT 1 FROM Proveedor
            WHERE IdProveedor = @IdProveedor
        )
            THROW 50002, 'Proveedor no existe', 1;

        -- Validar producto
        IF NOT EXISTS (
            SELECT 1 FROM Producto
            WHERE IdProducto = @IdProducto
        )
            THROW 50003, 'Producto no existe', 1;

        BEGIN TRANSACTION;

        DECLARE @IdCompra INT;
        DECLARE @Total DECIMAL(10,2);
        DECLARE @Estado INT;
        DECLARE @TipoMovimiento INT;

        SET @Total = @Cantidad * @PrecioCompra;

        SELECT @Estado = IdEstadoCompra
        FROM EstadoCompra
        WHERE Nombre = 'Completada';

        SELECT @TipoMovimiento = IdTipoMovimiento
        FROM TipoMovimiento
        WHERE Nombre = 'Entrada';

        IF @Estado IS NULL OR @TipoMovimiento IS NULL
            THROW 50004, 'Faltan estados o tipos de movimiento', 1;

        -- Registrar compra
        INSERT INTO Compra
        (IdProveedor, IdEstadoCompra, Total)
        VALUES
        (@IdProveedor, @Estado, @Total);

        SET @IdCompra = SCOPE_IDENTITY();

        -- Registrar detalle
        INSERT INTO DetalleCompra
        (IdCompra, IdProducto, Cantidad, PrecioCompra)
        VALUES
        (@IdCompra, @IdProducto, @Cantidad, @PrecioCompra);

        -- Aumentar inventario
        UPDATE Producto
        SET Existencia = Existencia + @Cantidad
        WHERE IdProducto = @IdProducto;

        -- Registrar movimiento
        INSERT INTO MovimientoInventario
        (IdProducto, IdTipoMovimiento, Cantidad, Observacion)
        VALUES
        (@IdProducto, @TipoMovimiento, @Cantidad, 'Compra de productos');

        COMMIT TRANSACTION;

        SELECT 'Compra registrada correctamente' AS Mensaje,
               @IdCompra AS IdCompra;

    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;

        THROW;
    END CATCH
END;
GO
--venta--
CREATE PROCEDURE RegistrarVenta
    @IdCliente INT,
    @IdProducto INT,
    @Cantidad INT
AS
BEGIN
    BEGIN TRY

        -- Validar cantidad
        IF @Cantidad IS NULL OR @Cantidad <= 0
            THROW 50001, 'Cantidad invalida', 1;

        -- Validar cliente
        IF NOT EXISTS (
            SELECT 1 FROM Cliente
            WHERE IdCliente = @IdCliente
        )
            THROW 50002, 'Cliente no existe', 1;

        -- Validar producto
        IF NOT EXISTS (
            SELECT 1 FROM Producto
            WHERE IdProducto = @IdProducto
        )
            THROW 50003, 'Producto no existe', 1;

        DECLARE @IdVenta INT;
        DECLARE @Precio DECIMAL(10,2);
        DECLARE @Total DECIMAL(10,2);
        DECLARE @Estado INT;
        DECLARE @TipoMovimiento INT;

        BEGIN TRANSACTION;

        -- Descontar inventario si hay suficientes existencias
        UPDATE Producto
        SET Existencia = Existencia - @Cantidad
        WHERE IdProducto = @IdProducto
          AND Existencia >= @Cantidad;

        IF @@ROWCOUNT = 0
            THROW 50004, 'Existencias insuficientes', 1;

        -- Obtener precio del producto
        SELECT @Precio = PrecioVenta
        FROM Producto
        WHERE IdProducto = @IdProducto;

        SET @Total = @Precio * @Cantidad;

        -- Obtener estado completada
        SELECT @Estado = IdEstadoVenta
        FROM EstadoVenta
        WHERE Nombre = 'Completada';

        -- Obtener tipo salida
        SELECT @TipoMovimiento = IdTipoMovimiento
        FROM TipoMovimiento
        WHERE Nombre = 'Salida';

        IF @Estado IS NULL OR @TipoMovimiento IS NULL
            THROW 50005, 'Faltan estados o tipos de movimiento', 1;

        -- Registrar venta
        INSERT INTO Venta
        (IdCliente, IdEstadoVenta, Total)
        VALUES
        (@IdCliente, @Estado, @Total);

        SET @IdVenta = SCOPE_IDENTITY();

        -- Registrar detalle de venta
        INSERT INTO DetalleVenta
        (IdVenta, IdProducto, Cantidad, PrecioUnitario)
        VALUES
        (@IdVenta, @IdProducto, @Cantidad, @Precio);

        -- Registrar salida de inventario
        INSERT INTO MovimientoInventario
        (IdProducto, IdTipoMovimiento, Cantidad, Observacion)
        VALUES
        (@IdProducto, @TipoMovimiento, @Cantidad, 'Venta de producto');

        COMMIT TRANSACTION;

        SELECT
            'Venta registrada correctamente' AS Mensaje,
            @IdVenta AS IdVenta,
            @Total AS Total;

    END TRY
    BEGIN CATCH

        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;

        THROW;

    END CATCH
END;
GO
--ReporteventaCliente--
CREATE PROCEDURE ReporteVentasCliente
AS
BEGIN
    SELECT
        c.Nombre AS Cliente,
        COUNT(v.IdVenta) AS CantidadVentas,
        SUM(v.Total) AS TotalGastado
    FROM Venta v
    INNER JOIN Cliente c
        ON v.IdCliente = c.IdCliente
    INNER JOIN EstadoVenta e
        ON v.IdEstadoVenta = e.IdEstadoVenta
    WHERE e.Nombre = 'Completada'
    GROUP BY c.IdCliente, c.Nombre
    ORDER BY TotalGastado DESC;
END;
GO
--reporteinventario--
CREATE PROCEDURE ReporteInventarioCategoria
AS
BEGIN
    SELECT
        c.Nombre AS Categoria,
        COUNT(p.IdProducto) AS CantidadProductos,
        SUM(p.Existencia) AS TotalExistencias
    FROM Producto p
    INNER JOIN Categoria c
        ON p.IdCategoria = c.IdCategoria
    GROUP BY c.IdCategoria, c.Nombre
    ORDER BY TotalExistencias DESC;
END;
GO